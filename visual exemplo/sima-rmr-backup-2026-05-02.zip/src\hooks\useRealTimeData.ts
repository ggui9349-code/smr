import { useState, useEffect } from 'react';
import { RiskLevel, SystemMode, type MonitoringArea, type Alert, type HistoricalData, type HistoricalEvent, type StationData } from '../types';

const MOCK_HISTORY: HistoricalEvent[] = [
  { time: '20:03', type: 'warning', description: 'Alerta | +10% em 5min' },
  { time: '20:00', type: 'trend', description: 'Taxa acelerou' },
  { time: '19:55', type: 'alert', description: 'Nível crítico atingido' },
  { time: '19:45', type: 'community', description: '5 novos relatos' },
  { time: '19:30', type: 'weather', description: 'Chuva intensificou' },
];

const MOCK_STATIONS: StationData[] = [
  { id: 'st1', name: 'Estação Beberibe', capacity: 5000, currentUsage: 3000, status: 'online' },
  { id: 'st2', name: 'Estação Imbiribeira', capacity: 3000, currentUsage: 500, status: 'online' },
];

const INITIAL_AREAS: MonitoringArea[] = [
  {
    id: '1',
    name: 'Bacia Pina - Setor Sul',
    municipality: 'Recife',
    coordinates: [-8.085, -34.895],
    futureCoordinates: [-8.088, -34.898],
    riskLevel: RiskLevel.CRITICAL,
    classification: 'R4',
    populationAtRisk: 8400,
    housesAtRisk: 2100,
    rainIntensity: 45.2,
    lastUpdate: new Date().toISOString(),
    trend: 'rising',
    eta: '12 min',
    confidence: 92.4,
    momentum: 0.8,
    causes: [
      { label: 'Chuva Intensa', intensity: 85 },
      { label: 'Drenagem Insuf.', intensity: 75 },
      { label: 'Sensibilidade', intensity: 60 }
    ],
    recommendations: ['Sirenes de alerta', 'Evacuação zona marcada', 'Fechar Av. Beberibe'],
    operationalPriority: 92,
    assignedTeams: 3,
    playbookStatus: 'active',
    urbanImpact: {
      schools: 3,
      hospitals: 1,
      blockedRoads: ['Av. Beberibe', 'Rua Imperial']
    },
    trustScore: 98,
    history: MOCK_HISTORY,
    stations: MOCK_STATIONS
  },
  {
    id: '2',
    name: 'Canal Arruda',
    municipality: 'Recife',
    coordinates: [-8.025, -34.892],
    riskLevel: RiskLevel.HIGH,
    classification: 'R3',
    populationAtRisk: 15000,
    housesAtRisk: 3800,
    rainIntensity: 32.5,
    lastUpdate: new Date().toISOString(),
    trend: 'rising',
    eta: '45 min',
    confidence: 88,
    momentum: 0.5,
    causes: [
      { label: 'Chuva Acumulada', intensity: 70 },
      { label: 'Canal Obstruído', intensity: 80 }
    ],
    recommendations: ['Monitoramento contínuo', 'Alerta preventivo'],
    operationalPriority: 75,
    assignedTeams: 2,
    playbookStatus: 'pending',
    urbanImpact: {
      schools: 5,
      hospitals: 0,
      blockedRoads: ['Rua Leopoldo Lins']
    },
    trustScore: 92,
    history: MOCK_HISTORY.slice(0, 3),
    stations: [MOCK_STATIONS[0]]
  },
  {
    id: '3',
    name: 'Rio Beberibe',
    municipality: 'Olinda',
    coordinates: [-8.005, -34.885],
    riskLevel: RiskLevel.ATTENTION,
    classification: 'R2',
    populationAtRisk: 12000,
    housesAtRisk: 2900,
    rainIntensity: 15.8,
    lastUpdate: new Date().toISOString(),
    trend: 'stable',
    eta: '120 min',
    confidence: 85,
    momentum: 0.2,
    causes: [
      { label: 'Maré Alta', intensity: 45 }
    ],
    recommendations: ['Vigilância ativa'],
    operationalPriority: 40,
    assignedTeams: 1,
    playbookStatus: 'pending',
    urbanImpact: {
      schools: 2,
      hospitals: 0,
      blockedRoads: []
    },
    trustScore: 80,
    history: [],
    stations: []
  },
  {
    id: '4',
    name: 'Imbiribeira',
    municipality: 'Recife',
    coordinates: [-8.105, -34.905],
    riskLevel: RiskLevel.SAFE,
    classification: 'R1',
    populationAtRisk: 25000,
    housesAtRisk: 6200,
    rainIntensity: 5.2,
    lastUpdate: new Date().toISOString(),
    trend: 'falling',
    eta: '--',
    confidence: 95,
    momentum: 0,
    causes: [],
    recommendations: ['Normalidade'],
    operationalPriority: 10,
    assignedTeams: 0,
    playbookStatus: 'pending',
    urbanImpact: {
      schools: 12,
      hospitals: 2,
      blockedRoads: []
    },
    trustScore: 99,
    history: [],
    stations: [MOCK_STATIONS[1]]
  }
];

const INITIAL_ALERTS: Alert[] = [
  {
    id: 'a1',
    areaId: '1',
    areaName: 'Bacia Pina - Setor Sul',
    municipality: 'Recife',
    level: RiskLevel.EXTREME,
    timestamp: new Date().toISOString(),
    eta: '12 min',
    description: 'Nível crítico esperado em 12 minutos. Impacto em 8.400 pessoas e 3 escolas.',
    channels: ['sms', 'push', 'radio'],
    actionType: 'evacuate'
  }
];

const HISTORICAL: HistoricalData[] = Array.from({ length: 12 }, (_, i) => ({
  time: `${i * 2}:00`,
  rain: 20 + Math.random() * 60,
  risk: 30 + Math.random() * 70,
}));

export function useRealTimeData() {
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [history] = useState<HistoricalData[]>(HISTORICAL);
  const [globalStatus] = useState<RiskLevel>(RiskLevel.CRITICAL);
  const [systemMode, setSystemMode] = useState<SystemMode>(SystemMode.CRITICAL);
  const [confidence] = useState(92.4);
  const [globalRiskScore, setGlobalRiskScore] = useState(74);
  const [isSimulating, setIsSimulating] = useState(false);
  const [timeOffset, setTimeOffset] = useState(0);
  const [decisionMode, setDecisionMode] = useState<'technical' | 'citizen'>('technical');
  const [areas, setAreas] = useState<MonitoringArea[]>(INITIAL_AREAS);

  useEffect(() => {
    const interval = setInterval(() => {
      setAreas(prev => prev.map(area => {
        const baseChange = (Math.random() - (isSimulating ? 0.2 : 0.45)) * 3;
        const timeEffect = timeOffset / 10;
        const newRain = Math.max(0, area.rainIntensity + baseChange + timeEffect);
        
        const newTrend: 'rising' | 'stable' | 'falling' = newRain > area.rainIntensity + 0.5 ? 'rising' : (newRain < area.rainIntensity - 0.5 ? 'falling' : 'stable');
        
        const riskScore = (newRain * 0.4) + (area.momentum * 30) + (area.confidence * 0.1);
        let newLevel = RiskLevel.SAFE;
        if (riskScore > 80) newLevel = RiskLevel.EXTREME;
        else if (riskScore > 60) newLevel = RiskLevel.CRITICAL;
        else if (riskScore > 40) newLevel = RiskLevel.HIGH;
        else if (riskScore > 20) newLevel = RiskLevel.ATTENTION;

        const priority = Math.min(100, (riskScore * 0.6) + (area.populationAtRisk / 1000 * 2));

        return {
          ...area,
          rainIntensity: newRain,
          riskLevel: newLevel,
          trend: newTrend,
          lastUpdate: new Date().toISOString(),
          confidence: Math.min(100, Math.max(50, area.confidence + (Math.random() - 0.5) * 1)),
          momentum: Math.min(2, Math.max(0, area.momentum + (Math.random() - 0.5) * 0.05)),
          operationalPriority: Math.round(priority)
        };
      }));
      
      setGlobalRiskScore(prev => {
        const delta = isSimulating ? 1.5 : (Math.random() - 0.5) * 0.5;
        return Math.min(100, Math.max(0, prev + delta));
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [isSimulating, timeOffset]);

  return { 
    areas, 
    alerts, 
    history, 
    globalStatus, 
    systemMode, 
    setSystemMode, 
    confidence, 
    globalRiskScore, 
    isSimulating, 
    setIsSimulating,
    timeOffset,
    setTimeOffset,
    decisionMode,
    setDecisionMode
  };
}
