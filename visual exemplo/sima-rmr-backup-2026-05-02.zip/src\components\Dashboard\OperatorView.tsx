import { useState, useMemo } from 'react';
import { type MonitoringArea, type Alert, type HistoricalData, RiskLevel } from '../../types';
import { Sidebar } from './Sidebar';
import { MapComponent } from './MapComponent';
import { DetailPanel } from './DetailPanel';
import { TopAlert } from './TopAlert';
import { ContextFooter } from './ContextFooter';
import { AnimatePresence } from 'motion/react';

interface OperatorViewProps {
  areas: MonitoringArea[];
  alerts: Alert[];
  history: HistoricalData[];
  globalStatus: RiskLevel;
  confidence: number;
  globalRiskScore: number;
}

export function OperatorView({ 
  areas, 
  alerts, 
  globalStatus, 
}: OperatorViewProps) {
  const [selectedAreaId, setSelectedAreaId] = useState<string>(areas[0].id);
  const [isAlertCollapsed, setIsAlertCollapsed] = useState(false);

  const selectedArea = useMemo(() => 
    areas.find(a => a.id === selectedAreaId) || areas[0],
    [areas, selectedAreaId]
  );

  const topAlertArea = useMemo(() => 
    areas.find(a => a.riskLevel === RiskLevel.EXTREME) || null,
    [areas]
  );

  return (
    <div className="flex h-[calc(100vh-80px)] w-full flex-col bg-[#0F172A] overflow-hidden">
      {/* Top 1 Alert Overlay/Header */}
      <AnimatePresence>
        {topAlertArea && (
          <TopAlert 
            area={topAlertArea} 
            isCollapsed={isAlertCollapsed}
            onToggleCollapse={() => setIsAlertCollapsed(!isAlertCollapsed)}
          />
        )}
      </AnimatePresence>

      <div className="flex flex-1 flex-row overflow-hidden">
        {/* Painel Esquerdo (20%) */}
        <aside className="w-[20%] border-r border-white/5 shadow-2xl z-20">
          <Sidebar 
            areas={areas} 
            selectedId={selectedAreaId} 
            onSelect={(area) => setSelectedAreaId(area.id)} 
          />
        </aside>

        {/* Mapa Central (60%) */}
        <main className="relative flex-1 z-10">
          <MapComponent 
            areas={areas} 
            onAreaSelect={(area) => setSelectedAreaId(area.id)}
            focusedArea={selectedArea}
          />
        </main>

        {/* Painel Direito (20%) */}
        <aside className="w-[20%] border-l border-white/5 shadow-2xl z-20 overflow-y-auto">
          <DetailPanel area={selectedArea} />
        </aside>
      </div>

      {/* Footer Contextual */}
      <ContextFooter area={selectedArea} />
    </div>
  );
}
