import { useState } from 'react';
import { Header } from './components/Dashboard/Header';
import { CitizenView } from './components/Citizen/CitizenView';
import { OperatorView } from './components/Dashboard/OperatorView';
import { useRealTimeData } from './hooks/useRealTimeData';
import { cn } from './lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { RiskLevel } from './types';

export default function App() {
  const { 
    areas, 
    alerts, 
    history, 
    globalStatus, 
    systemMode, 
    confidence, 
    globalRiskScore, 
    isSimulating, 
    setIsSimulating,
    decisionMode,
    setDecisionMode
  } = useRealTimeData();
  
  const isExtremeAlert = globalRiskScore > 85;

  return (
    <div className={cn(
      "flex h-screen flex-col transition-all duration-1000 overflow-hidden",
      isExtremeAlert ? "bg-red-950/20" : "bg-[#f8fafc]"
    )}>
      <Header 
        status={globalStatus} 
        mode={systemMode} 
        confidence={confidence} 
        globalRiskScore={globalRiskScore}
        isSimulating={isSimulating}
        onToggleSimulation={() => setIsSimulating(!isSimulating)}
        decisionMode={decisionMode === 'technical' ? 'operator' : 'citizen'}
        onModeToggle={(mode) => setDecisionMode(mode === 'operator' ? 'technical' : 'citizen')}
      />

      <main className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {decisionMode === 'citizen' ? (
            <motion.div
              key="citizen"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="h-full w-full overflow-y-auto"
            >
              <CitizenView areas={areas} />
            </motion.div>
          ) : (
            <motion.div
              key="operator"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-full w-full"
            >
              <OperatorView 
                areas={areas}
                alerts={alerts}
                history={history}
                globalStatus={globalStatus}
                confidence={confidence}
                globalRiskScore={globalRiskScore}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* EMERGENCY OVERLAY (OPERATOR ONLY) */}
        <AnimatePresence>
          {isExtremeAlert && decisionMode === 'technical' && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[40] pointer-events-none"
            >
               <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_rgba(0,0,0,0.6)_100%)]" />
               
               {/* Critical Warnings Floating */}
               <div className="absolute bottom-24 left-12 p-8 border-l-4 border-red-600 bg-black/80 backdrop-blur-md z-[60]">
                  <p className="text-4xl font-black text-white italic tracking-tighter uppercase whitespace-nowrap">Prioridade R4 Detectada</p>
                  <p className="text-xs font-bold text-red-500 uppercase tracking-widest mt-2 animate-pulse">Check Operational Deck Immediately</p>
               </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
